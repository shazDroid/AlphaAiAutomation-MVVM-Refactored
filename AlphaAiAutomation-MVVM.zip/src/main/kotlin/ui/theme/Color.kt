package ui.theme

const val BLUE = 0xFF687EF5